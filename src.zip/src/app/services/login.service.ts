import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private validCredentials = {
    user: 'recepcion',
    pass: '123456'
  };

  isAuthenticated(username: string, password: string): boolean {
    return username === this.validCredentials.user && password === this.validCredentials.pass;
  }

  initializeLogin(): void {
    if (!localStorage.getItem('isLoggedIn')) {
      localStorage.setItem('isLoggedIn', 'false');
    }
  }

  setLoginStatus(status: boolean): void {
    localStorage.setItem('isLoggedIn', status.toString());
  }

  getLoginStatus(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }
}