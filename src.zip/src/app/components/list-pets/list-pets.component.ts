import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-list-pets',
  templateUrl: './list-pets.component.html',
  styleUrls: ['./list-pets.component.scss'],
  imports: [CommonModule, RouterModule]
})
export class ListPetsComponent {
  pets = [
    { id: 1, name: 'Fido', species: 'Dog', owner: 'John Doe' },
    { id: 2, name: 'Whiskers', species: 'Cat', owner: 'Jane Smith' }
  ];
  menuOptions = [
    { label: 'Paciente', route: '/list-pets' },
    { label: 'Citas', route: '/list-appointments' },
    { label: 'Nueva Cita', route: '/appointment-schedule' },
    { label: 'Atencion', route: '/appointment-attention' },
    { label: 'Historial', route: '/medical-history' },
    { label: 'Detalle Atencion', route: '/attention-details' }
  ];
}