import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  imports: [CommonModule, RouterModule]
})
export class HomeComponent {
  menuOptions = [
    { label: 'Paciente', route: '/list-pets' },
    { label: 'Citas', route: '/list-appointments' },
    { label: 'Nueva Cita', route: '/appointment-schedule' },
    { label: 'Atencion', route: '/appointment-attention' },
    { label: 'Historial', route: '/medical-history' },
    { label: 'Detalle Atencion', route: '/attention-details' }
  ];
}