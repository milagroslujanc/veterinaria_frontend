import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-main-interface',
  templateUrl: './main-interface.component.html',
  styleUrls: ['./main-interface.component.scss'],
  imports: [CommonModule, RouterModule]
})
export class MainInterfaceComponent {
  menuOptions = [
    { label: 'Paciente', route: '/paciente' },
    { label: 'Citas', route: '/citas' },
    { label: 'Atencion', route: '/atencion' },
    { label: 'Historial', route: '/historial' }
  ];
}