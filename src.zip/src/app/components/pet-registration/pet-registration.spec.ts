import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PetRegistration } from './pet-registration';

describe('PetRegistration', () => {
  let component: PetRegistration;
  let fixture: ComponentFixture<PetRegistration>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PetRegistration]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PetRegistration);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
