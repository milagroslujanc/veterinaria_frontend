import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-pet-registration',
  templateUrl: './pet-registration.html',
  styleUrls: ['./pet-registration.scss'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule]
})
export class PetRegistrationComponent implements OnInit {
  petForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.petForm = this.fb.group({
      idMascota: ['', Validators.required],
      nombre: ['', Validators.required],
      especie: ['', Validators.required],
      raza: ['', Validators.required],
      sexo: ['', Validators.required],
      fechaNacimiento: ['', Validators.required],
      peso: ['', [Validators.required, Validators.min(0)]],
      color: ['', Validators.required],
      dueño: ['', Validators.required],
      celularContacto: ['', [Validators.required, Validators.pattern(/^\d{9}$/)]],
      correoContacto: ['', [Validators.required, Validators.email]],
      fechaRegistro: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.petForm.valid) {
      const petData = this.petForm.value;
      localStorage.setItem(`mascota_${Date.now()}`, JSON.stringify(petData));
      alert('Mascota registrada exitosamente');
      this.petForm.reset();
    } else {
      alert('Por favor, complete todos los campos correctamente.');
    }
  }
}