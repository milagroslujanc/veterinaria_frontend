import { Component } from '@angular/core';

@Component({
  selector: 'app-attention-details',
  templateUrl: './attention-details.component.html',
  styleUrls: ['./attention-details.component.scss']
})
export class AttentionDetailsComponent {
  attentionDetail = {
    id: 1,
    pet: 'Fido',
    date: '2025-11-10',
    time: '10:00 AM',
    description: 'Routine check-up',
    veterinarian: 'Dr. Smith'
  };
}