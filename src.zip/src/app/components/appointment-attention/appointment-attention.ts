import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-appointment-attention',
  templateUrl: './appointment-attention.html',
  styleUrls: ['./appointment-attention.scss'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule]
})
export class AppointmentAttentionComponent implements OnInit {
  attentionForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.attentionForm = this.fb.group({
      idAtencion: ['', Validators.required],
      idCita: ['', Validators.required],
      fechaAtencionReal: ['', Validators.required],
      veterinario: ['', Validators.required],
      diagnostico: ['', Validators.required],
      procedimiento: ['', Validators.required],
      receta: ['', Validators.required],
      estadoFinal: ['', Validators.required],
      proximoControl: ['']
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.attentionForm.valid) {
      const attentionData = this.attentionForm.value;
      console.log('Attention Data:', attentionData);
      alert('Atención registrada exitosamente');
      this.attentionForm.reset();
    } else {
      alert('Por favor, complete todos los campos correctamente.');
    }
  }
}