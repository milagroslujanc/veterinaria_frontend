import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';

@Component({
  selector: 'app-medical-history',
  templateUrl: './medical-history.html',
  styleUrls: ['./medical-history.scss'],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatSelectModule, MatOptionModule]
})
export class MedicalHistoryComponent implements OnInit {
  medicalHistoryForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.medicalHistoryForm = this.fb.group({
      idHistorial: ['', Validators.required],
      idMascota: ['', Validators.required],
      fechaAtencion: ['', Validators.required],
      veterinario: ['', Validators.required],
      diagnostico: ['', Validators.required],
      tratamiento: ['', Validators.required],
      vacunasAplicadas: ['', Validators.required],
      pesoActual: ['', [Validators.required, Validators.min(0)]],
      observaciones: ['']
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.medicalHistoryForm.valid) {
      const historyData = this.medicalHistoryForm.value;
      console.log('Medical History Data:', historyData);
      alert('Historial médico registrado exitosamente');
      this.medicalHistoryForm.reset();
    } else {
      alert('Por favor, complete todos los campos correctamente.');
    }
  }
}