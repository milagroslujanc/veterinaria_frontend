import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-appointment-schedule',
  templateUrl: './appointment-schedule.html',
  styleUrls: ['./appointment-schedule.scss'],
})
export class AppointmentSchedule {
  appointmentForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.appointmentForm = this.fb.group({
      idCita: ['', Validators.required],
      idMascota: ['', Validators.required],
      fechaCita: ['', Validators.required],
      horaCita: ['', Validators.required],
      motivo: ['', Validators.required],
      veterinarioAsignado: ['', Validators.required],
      estadoCita: ['', Validators.required],
      observaciones: [''],
      fechaRegistro: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.appointmentForm.valid) {
      console.log('Appointment Data:', this.appointmentForm.value);
    }
  }
}
