import { Component } from '@angular/core';

@Component({
  selector: 'app-list-appointments',
  templateUrl: './list-appointments.component.html',
  styleUrls: ['./list-appointments.component.scss']
})
export class ListAppointmentsComponent {
  appointments = [
    // Example data, replace with actual data fetching logic
    { id: 1, date: '2025-11-10', time: '10:00 AM', pet: 'Fido' },
    { id: 2, date: '2025-11-11', time: '2:00 PM', pet: 'Whiskers' }
  ];
}