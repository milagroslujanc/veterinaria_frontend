import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MainInterfaceComponent } from './components/main-interface/main-interface.component';
import { HomeComponent } from './components/home/home.component';
import { ListAppointmentsComponent } from './components/list-appointments/list-appointments.component';
import { AttentionDetailsComponent } from './components/attention-details/attention-details.component';
import { PetRegistrationComponent } from './components/pet-registration/pet-registration';
import { ListPetsComponent } from './components/list-pets/list-pets.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'main', component: MainInterfaceComponent },
  { path: 'home', component: HomeComponent },
  { path: 'list-appointments', component: ListAppointmentsComponent },
  { path: 'attention-details', component: AttentionDetailsComponent },
  { path: 'pet-registration', component: PetRegistrationComponent },
  { path: 'list-pets', component: ListPetsComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
];
